<?php
class Users {
	public $con;
	private $table = "Users";

	public $userID;

	public $firstname;
	public $lastname;
	public $useremail;
	public $userphone;

	public $password;
	
	public $nic;
	public $address;
	
	public $code;
	public $token;
	public $otp;
	public $lastLogin;
	public $type;
	public $active;

	// Constructor with correct method name
	public function __construct(){
		$database = new Database();
        $this->con = $database->con;
	}

	public function register($data){
		$this->firstname = htmlspecialchars(strip_tags($data['firstname']));
		$this->lastname = htmlspecialchars(strip_tags($data['lastname']));
		$this->useremail = htmlspecialchars(strip_tags($data['useremail']));
		$this->userphone = htmlspecialchars(strip_tags($data['userphone']));

		$this->password = password_hash('1234', PASSWORD_DEFAULT);
		
		$this->nic = htmlspecialchars(strip_tags($data['nic']));
		$this->address = htmlspecialchars(strip_tags($data['address']));

		$this->code = time();
		$this->token = md5($this->useremail.$this->nic.$this->code);  
		$this->otp = '0';
		$this->lastLogin = date("Y-m-d H:i:s");
		// Set user type based on the data input
		if($data['type'] == "Passenger"){
			$this->type = "1";
		}elseif($data['type'] == "Driver"){
			$this->type = "2";
		}

		$this->active = "1";


		// Check if the email is already registered
		if($this->checkUserEmail()){
		
			?>
			<div class="alert alert-warning" role="alert">
	            <h5 style="text-align: center;"><b>The Email is already registered.</b></h5>
	        </div>
			<?php
		}else{
			$sql = "INSERT INTO $this->table (
				userID, 
				firstname, 
				lastname, 
				useremail, 
				userphone, 
				password, 
				nic, 
				address, 
				code, 
				token, 
				otp, 
				lastLogin, 
				type, 
				active
			) VALUES (
				null, 
				'$this->firstname', 
				'$this->lastname', 
				'$this->useremail', 
				'$this->userphone', 
				'$this->password', 
				'$this->nic', 
				'$this->address', 
				'$this->code', 
				'$this->token', 
				'$this->otp', 
				'$this->lastLogin', 
				'$this->type', 
				'$this->active'
			)";

			$exe = $this->con->query($sql);
			if($exe){
				// Success
				?>
				<div class="alert alert-success" role="alert">
					<h5 style="text-align: center;"><b>Registration Successful!</b></h5>
				</div>
				<?php
			}else{
				// SQL execution failed
				?>
				<div class="alert alert-warning" role="alert">
					<h5 style="text-align: center;"><?php echo $this->con->error; ?></h5>
				</div>
				<?php
			}
		}

	}


	public function checkUserEmail(){
		$queryCheck = "SELECT * FROM $this->table WHERE useremail = '$this->useremail' AND active != '0'";
		$exe = $this->con->query($queryCheck);
		if(mysqli_num_rows($exe)>=1){
			return true;
		}else{
			return false;
		}
	}
}
?>

<?php require "include/setting.php"; ?>
<!DOCTYPE html>
<html>

<head>
  <title>Blank</title>

  <?php include "include/head.php"; ?>
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <?php include "include/header.php"; ?>
    <!-- end header section -->

  </div>

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container">
      <div class="row justify-content-center">
        
        <div class="col-md-5">
          <div class="card">
            <div class="card-header">
              <h2 class="text-center">Login</h2>
            </div>
            
            <div class="card-body">
              <form action="" method="post">

                <div class="form-group">
                  <input type="email" name="useremail" class="form-control" placeholder="Email " required>
                </div>

                <div class="form-group">
                  <input type="password" name="password" class="form-control" placeholder="Password " required>
                </div>

                <div class="form-group">
                  <button class="form-control btn btn-primary" name="btnLogin">Login</button>
                </div>

                <div class="form-group text-center">
                  <a href="register.php">Don't have an account?</a>
                </div>
              </form>
              
            </div>

          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- end about section -->


  


  <!-- footer section -->
  <?php include "include/footer.php"; ?>
  <!-- footer section -->


  <?php include "include/bottom.php"; ?>

</body>

</html>